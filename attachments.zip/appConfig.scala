package com.figmd.csvparser

import java.util.Properties

class appConfiguration(args0: String,args1: String) {
  val bucketNm = args0
  val appPath = args1
  val configFilePath = "s3://"+bucketNm+"/"+appPath
  val awsAccessKey="AKIALH6XLTJCI6I3N5RQ"
  val awsSecretKey="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"

  //val awsAccessKey = "AKIAJC2BI34Q3U2RAHKA"
  //val awsSecretKey = "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"


  val spark = appUtilities.createSparkSession(awsAccessKey,awsSecretKey)

/*  val configFileLinesToList = Source.fromFile(configFilePath).getLines().foreach(line => {
    val fieldName = line.split("=")(0)
    val fieldValue = line.split("=")(1)
    configFileMap += (fieldName -> fieldValue.trim)
    })
    */
  var configFileMap = Map[String, String]()
  spark.sparkContext.textFile(configFilePath).collect().foreach(line => {
    val fieldName = line.split("=")(0)
    val fieldValue = line.split("=")(1)
    configFileMap += (fieldName -> fieldValue.trim)
  })

  val prop = new Properties()
  prop.setProperty("BucketName", configFileMap("BucketName"))
  prop.setProperty("awsAccessKey", configFileMap("awsAccessKey"))
  prop.setProperty("awsSecretKey", configFileMap("awsSecretKey"))
  prop.setProperty("inputFilepath", configFileMap("inputFilepath"))
  prop.setProperty("primaryConfig", configFileMap("primaryConfig"))
  prop.setProperty("supportingConfig", configFileMap("supportingConfig"))
  prop.setProperty("locationPracticeUIDconfig",configFileMap("locationPracticeUIDconfig"))
  prop.setProperty("DataFileDelimiter", configFileMap("DataFileDelimiter"))
  prop.setProperty("outputFilePath", configFileMap("outputFilePath"))
  prop.setProperty("outputFileDelimiter", configFileMap("outputFileDelimiter"))
  prop.setProperty("renameFilePattern", configFileMap("renameFilePattern"))
  prop.setProperty("renameScriptPath", configFileMap("renameScriptPath"))
  prop.setProperty("isfileListingReqd", configFileMap("isfileListingReqd"))
  prop.setProperty("hasDirNameDependency",configFileMap("hasDirNameDependency"))
  prop.setProperty("hasFileNameDependency",configFileMap("hasFileNameDependency"))
  prop.setProperty("regexToMatch",configFileMap("regexToMatch"))
  prop.setProperty("replacementFromMatch",configFileMap("replacementFromMatch"))
  prop.setProperty("filterColName",configFileMap("filterColName"))
  prop.setProperty("joinDFName",configFileMap("joinDFName"))
  prop.setProperty("joinKey",configFileMap("joinKey"))
  prop.setProperty("columnToDropPostJoin",configFileMap("columnToDropPostJoin"))
  prop.setProperty("joinDFColumns",configFileMap("joinDFColumns"))
  prop.setProperty("hasGroupLevelData",configFileMap("hasGroupLevelData"))
}
