package com.figmd.csvparser
import com.amazonaws.services.s3.AmazonS3
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import scala.collection.mutable.ListBuffer

object appUtilities {
  def createSparkSession(awsAccessKey : String,awsSecretKey : String): SparkSession ={
    val spark: SparkSession = SparkSession
      .builder()
      .master("local")
      //.master("yarn")
      .appName("CSV data processor")
      .config("fs.s3n.impl","org.apache.hadoop.fs.s3native.NativeS3FileSystem")
      .config("fs.s3.awsAccessKeyId", awsAccessKey)
      .config("fs.s3.awsSecretAccessKey", awsSecretKey)
      .getOrCreate()
    return spark
  }


  def listFilesInDir(dirName : String,inputFilePath : String, BucketName : String, s3Client : AmazonS3): ListBuffer[String] ={
    val fileList = ListBuffer[String]()
    val Filepath = inputFilePath+dirName+"/"
    val fileObjects = s3Client.listObjects(BucketName, Filepath)
    for (i <- 0 to fileObjects.getObjectSummaries.size -1 ) {
      fileList.append("s3://bd-dev/" + fileObjects.getObjectSummaries.get(i).getKey)
    }
    return fileList
  }

  def extractShortName(name_str : String,regex_to_match : String, replacement_from_match : String): String ={
    val pattern = regex_to_match.r
    val shortname = pattern.findFirstIn(name_str).toString.replace(replacement_from_match,"").replace(" ","")
      .substring(5,pattern.findFirstIn(name_str).toString.replace(replacement_from_match,"").replace(" ","").length -1)
    return shortname
  }

  def createJoinDF(spark : SparkSession,temp_df_filepath : String,file_df_filepath : String,temp_df_columns : Array[String],join_key : String,col_to_drop : String,
                   file_delimiter: String) :DataFrame ={
    import spark.implicits._
    val temp_df = spark.read.option("header", "true").option("delimiter", file_delimiter).csv(temp_df_filepath).cache()
    val required_temp_df = temp_df.select(temp_df_columns.head,temp_df_columns.tail: _*).withColumn("dummy",lit("")).cache()
    val file_df = spark.read.option("header", "true").option("delimiter", file_delimiter).csv(file_df_filepath)
    val join_df = file_df.as("df1").join(required_temp_df.as("df2"),regexp_replace($"df1.$join_key","Z","0") === $"df2.$join_key")
      .drop($"df2.$join_key").drop($"df1.$col_to_drop")
      .withColumn("dummy", lit("")).cache()
    return join_df
  }


  def createReqiredDF(spark : SparkSession,input_df : DataFrame,col_transpose_flg :String,cols_to_transpose : List[String],transpose_col_index :Int,section_uid : String,
                      practice_uid : String, columnSequenceRequired : Array[String],output_filepath : String):String= {
    import spark.implicits._
    val df = input_df.withColumn("PracticeUid", lit(practice_uid))
    val columnsInDF = df.schema.fieldNames
    val missingColumns = columnSequenceRequired.filterNot(l=> columnsInDF.mkString(",").toUpperCase.split(",").contains(l.toUpperCase))
    val addMissingCols = missingColumns.foldLeft(df)((df, name) => df.withColumn(name, $"dummy")).drop("dummy")
    var filenamelist = ListBuffer[String]()
    if(col_transpose_flg == "YES"){
      cols_to_transpose.foreach(cols => {
        columnSequenceRequired(transpose_col_index) = cols
        val finalDf = addMissingCols.select(columnSequenceRequired.head, columnSequenceRequired.tail: _*)
        val write_time = LocalDateTime.now.format(DateTimeFormatter.ofPattern("YYYYMMddHHmmss.SSS"))
        var filename = output_filepath + section_uid + "_" + practice_uid + "_" + write_time + ".txt"
        finalDf.withColumn("emptyCol1", lit("")).withColumn("emptyCol2", lit(""))
          .coalesce(1).write.mode("Overwrite") /*.option("header","true")*/ .option("delimiter", "\u0017").csv(filename)
        filenamelist.append(filename)
      })
      return filenamelist.mkString("|")
    }
    else{
      val finalDf = addMissingCols.select(columnSequenceRequired.head, columnSequenceRequired.tail: _*)
      val write_time = LocalDateTime.now.format(DateTimeFormatter.ofPattern("YYYYMMddHHmmss.SSS"))
      var filename = output_filepath + section_uid + "_" + practice_uid + "_" + write_time + ".txt"
      finalDf.withColumn("emptyCol1", lit("")).withColumn("emptyCol2", lit(""))
        .coalesce(1).write.mode("Overwrite") /*.option("header","true")*/ .option("delimiter", "\u0017").csv(filename)
      return filename
    }
  }
}
