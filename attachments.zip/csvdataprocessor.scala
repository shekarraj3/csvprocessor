package com.figmd.csvparser

import com.amazonaws.auth.{AWSStaticCredentialsProvider, BasicAWSCredentials}
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import scala.collection.mutable.ListBuffer
import sys.process._

object csvdataprocessor {
  def main(args: Array[String]): Unit = {
    val bucketnm = args(0)
    val appPath = args(1)
    //appConfig
    appUtilities

    val awsAccessKey="AKIALH6XLTJCI6I3N5RQ"
    val awsSecretKey="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"


    //val awsAccessKey = "AKIAJC2BI34Q3U2RAHKA"
    //val awsSecretKey = "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"
    val spark = appUtilities.createSparkSession(awsAccessKey,awsSecretKey)

    /** Building spark session with s3 as the native file system */
    //val awsAccessKey = appConfig.prop.getProperty("awsAccessKey")
    //val awsSecretKey = appConfig.prop.getProperty("awsSecretKey")

    /*    val spark: SparkSession = SparkSession
          .builder()
          .master("local")
          .appName("CSV data processor")
          .config("fs.s3n.impl","org.apache.hadoop.fs.s3native.NativeS3FileSystem")
          //.config("fs.s3.awsAccessKeyId", awsAccessKey)
          //.config("fs.s3.awsSecretAccessKey", awsSecretKey)
          .getOrCreate()*/
    val appConfig = new appConfiguration(args(0),args(1))

    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    import spark.implicits._

    /** Declaring the required variables and assigning the values from the configuration file */
    val BucketName = appConfig.prop.getProperty("BucketName")
    val inputFilePath = appConfig.prop.getProperty("inputFilepath")
    val isFileListingReqd = appConfig.prop.getProperty("isfileListingReqd")

    val primaryConfig = spark.sparkContext.textFile(appConfig.prop.getProperty("primaryConfig")).cache().collect().toList
    var supportingConfig = spark.sparkContext.parallelize(List("")).cache().collect().toList
    if(appConfig.prop.getProperty("supportingConfig") != "NA") {
      supportingConfig = spark.sparkContext.textFile(appConfig.prop.getProperty("supportingConfig")).cache().collect().toList
    }
    val hasDirNameDependency= appConfig.prop.getProperty("hasDirNameDependency").toUpperCase
    val hasFileNameDependency= appConfig.prop.getProperty("hasFileNameDependency").toUpperCase
    val hasGroupLevelData = appConfig.prop.getProperty("hasGroupLevelData").toUpperCase


    /** Appending values to the practice UID map by parsing each line of the location practice uid config file */
    var practice_UID_map = Map[String, String]()
    if(appConfig.prop.getProperty("locationPracticeUIDconfig") != "NA") {
      spark.sparkContext.textFile(appConfig.prop.getProperty("locationPracticeUIDconfig")).cache().collect().foreach(line => {
        val sname = line.split(";")(0)
        val pracUID = line.split(";")(1)
        practice_UID_map += (sname -> pracUID.toLowerCase)
      })
    }

    /** Building the s3 client to send request to the S3 filesystem to get desired output */
    val credentials = new BasicAWSCredentials(awsAccessKey, awsSecretKey)
    val s3Client = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials)).build()

    /** Listing the directories available in the input path location on s3
      * This uses a shell command call from scala which then returns the output to a scala variable
      * The output is then formatted to get the derired values
      * */
    val finaldirs = ListBuffer[String]()
    val opt = s"aws s3 ls $BucketName/$inputFilePath".!!
    val dirList = opt.split("\n")
    dirList.foreach(e => finaldirs.append(e.reverse.split("/")(1).reverse.trim.replace("PRE ","")))

    /** This block of code will execute If the content inside the directory has section specific data
      * The practice information will be fetched from the directory name
      * The files may have a dependency on some other file for some information for which a join will be required on the dataframes
      * */

    var practice = "none"
    finaldirs.foreach(dir => {
      var fileListForRenaming = ListBuffer[String]()
      try {
        if (hasDirNameDependency == "YES") {
          practice = appUtilities.extractShortName(dir, appConfig.prop.getProperty("regexToMatch"), appConfig.prop.getProperty("replacementFromMatch"))
        }
        var cols_to_transpose = List[String]()
        var transpose_col_index = 0
        if (isFileListingReqd == "YES") {
          val fileList = appUtilities.listFilesInDir(dir, inputFilePath, BucketName, s3Client)
          primaryConfig.foreach(line => {
            val section_ID = line.split(";")(0)
            val filename_pattern = line.split(";")(1)
            val output_file_schema = line.split(";")(2).split(",")
            val isColTransposeReqd = line.split(";")(3).toUpperCase
            val isJoinReqd = line.split(";")(6).toUpperCase
            if (isColTransposeReqd == "YES") {
              cols_to_transpose = line.split(";")(4).split(",").toList
              transpose_col_index = line.split(";")(5).toInt
            }
            val fileName = fileList.filter(x => x.contains(filename_pattern)).head
            if (hasFileNameDependency == "YES"){
              practice = appUtilities.extractShortName(dir, appConfig.prop.getProperty("regexToMatch"), appConfig.prop.getProperty("replacementFromMatch"))
            }
            var df = spark.createDataFrame(Seq((1, 2), (1, 2))).toDF("Blank1", "Blank2")
            if (isJoinReqd == "YES") {
              val file_pattern_for_tempdf = appConfig.prop.getProperty("joinDFName")
              df = appUtilities.createJoinDF(spark, fileList.filter(x => x.contains(file_pattern_for_tempdf)).head, fileList.filter(x => x.contains(filename_pattern)).head,
                appConfig.prop.getProperty("joinDFColumns").split(","), appConfig.prop.getProperty("joinKey"), appConfig.prop.getProperty("columnToDropPostJoin"),
                appConfig.prop.getProperty("DataFileDelimiter"))
            }
            else {
              df = spark.read.option("header", "true").option("delimiter", appConfig.prop.getProperty("DataFileDelimiter")).csv(fileName)
                .withColumn("dummy", lit(""))
            }
            if (hasGroupLevelData == "YES") {
              supportingConfig.foreach(section => {
                val filterLocations = section.split(";")(0).split(",").toList
                practice = section.split(";")(1).toLowerCase
                df = df.filter($"Service LocationName".isin(filterLocations: _*))
                val output_filename = appUtilities.createReqiredDF(spark, df, isColTransposeReqd, cols_to_transpose, transpose_col_index, section_ID, practice,
                  output_file_schema, appConfig.prop.getProperty("outputFilePath"))
                output_filename.split("\\|").foreach(file => fileListForRenaming.append(file))
              })
            }
            else {
              val output_filename = appUtilities.createReqiredDF(spark, df, isColTransposeReqd, cols_to_transpose, transpose_col_index, section_ID, practice_UID_map(practice),
                output_file_schema, appConfig.prop.getProperty("outputFilePath"))
              output_filename.split("\\|").foreach(file => fileListForRenaming.append(file))
            }
          })
        }
        /** This Block of code will execute when the file listing is not required
          * the files will have same header so there won't be any inter dependency and hence no join scenarios handle would be required
          * */
        else {
          var location_list = ListBuffer[String]()
          val datadir_path = "s3://" + BucketName + "/" + inputFilePath + dir +"/"
          val filter_col_name = appConfig.prop.getProperty("filterColName")
          val df = spark.read.option("header", "true").csv(datadir_path).cache()
          df.select(s"$filter_col_name").distinct().rdd.map(r => r(0)).collect().foreach(e => location_list.append(e.toString))
          location_list.foreach(loc => {
            try {
              practice_UID_map(loc)
            }
            catch {
              case ex1: NoSuchElementException => {
                location_list -= loc
                None
              }
            }
          })
          location_list.foreach(location => {
            practice = location
            val df_per_practice = df.filter($"$filter_col_name" === s"$location").withColumn("dummy", lit("")).cache()
            primaryConfig.foreach(line => {
              val section_ID = line.split(";")(0)
              val output_file_schema = line.split(";")(2).split(",")
              val isColTransposeReqd = line.split(";")(3).toUpperCase
              val isJoinReqd = line.split(";")(6).toUpperCase
              if (isColTransposeReqd == "YES") {
                cols_to_transpose = line.split(";")(4).split(",").toList
                transpose_col_index = line.split(";")(5).toInt
              }
              else {
                cols_to_transpose = "none".split(",").toList
                transpose_col_index = 0
              }
              val output_filename = appUtilities.createReqiredDF(spark, df_per_practice, isColTransposeReqd, cols_to_transpose, transpose_col_index, section_ID,
                practice_UID_map(practice), output_file_schema, appConfig.prop.getProperty("outputFilePath"))
              output_filename.split("\\|").foreach(file => fileListForRenaming.append(file))
            })
          })
        }
      }
      catch {
        case ex: ArrayIndexOutOfBoundsException => {
          println(s"Index out Of Bound  $ex")}
        case ex1: NoSuchElementException => {
          println(s"Such element is not present $ex1")}
        case ex2: NullPointerException => {
          println(s" Null pointer $ex2")}
        case unknown: Exception => {
          println(s"Unknown exception: $unknown")}
      }
      /**This block call a shell script to rename the part files generated by spark
        * */
      val filepattern = appConfig.prop.getProperty("renameFilePattern")
      val list_of_dir = fileListForRenaming.mkString(",")
      val renameScriptPath = appConfig.prop.getProperty("renameScriptPath")
      val outputFilePath = appConfig.prop.getProperty("outputFilePath")
      val result = s"$renameScriptPath $filepattern $list_of_dir $outputFilePath".!!
    })
  }
}